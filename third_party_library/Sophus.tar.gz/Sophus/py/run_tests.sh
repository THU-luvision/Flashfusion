#bin/bash

python3 -m sophus.complex
python3 -m sophus.quaternion
python3 -m sophus.dual_quaternion
python3 -m sophus.so2
python3 -m sophus.se2
python3 -m sophus.so3
python3 -m sophus.se3