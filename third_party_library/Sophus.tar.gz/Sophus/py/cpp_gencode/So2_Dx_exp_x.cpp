result[0] = -sin(theta);
result[1] = cos(theta);
